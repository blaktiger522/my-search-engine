
import json
from replit import db
from datetime import datetime

# Create timestamped backup filename
timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
filename = f'backup_{timestamp}.json'

# Export data
data = {}
for key in db.keys():
    data[key] = db[key]

# Save with timestamp in metadata
backup_data = {
    'metadata': {
        'timestamp': timestamp,
        'total_records': len(data)
    },
    'data': data
}

with open(filename, 'w') as f:
    json.dump(backup_data, f, indent=2)

print(f"Data exported to {filename}")

# Push backup to GitHub
import os
os.system(f"git add {filename}")
os.system('git commit -m "Automated backup {}"'.format(timestamp))
os.system('git push')
