
import os
import psycopg2
from urllib.parse import urlparse

# Get database connection string from environment
db_url = os.getenv('DATABASE_URL')
if not db_url:
    print("No DATABASE_URL environment variable found")
    exit(1)

# Parse the connection URL
result = urlparse(db_url)
username = result.username
password = result.password
database = result.path[1:]
hostname = result.hostname
port = result.port

# Connect to database
conn = psycopg2.connect(
    database = database,
    user = username,
    password = password,
    host = hostname,
    port = port
)

cursor = conn.cursor()

# Get list of tables
cursor.execute("""
    SELECT table_name 
    FROM information_schema.tables 
    WHERE table_schema = 'public'
""")

tables = cursor.fetchall()

# Print data from each table
for table in tables:
    table_name = table[0]
    print(f"\nTable: {table_name}")
    cursor.execute(f"SELECT * FROM {table_name}")
    rows = cursor.fetchall()
    if rows:
        for row in rows:
            print(row)
    else:
        print("No data")

conn.close()
