# Profile Completion Page Mockups

## 1. Resume Upload Tab with "Complete with Resume Only" Button

```
┌──────────────────────────────────────────────────────────┐
│ Tell us more about yourself                              │
│ Upload your resume to get started immediately.           │
│ Additional profile details are optional but help us      │
│ match you better.                                        │
├──────────────────────────────────────────────────────────┤
│ [ Resume & Photo ] [ Job Preferences ] [ Add. Criteria ] │
├──────────────────────────────────────────────────────────┤
│                                                          │
│ ┌────────────────────┐    ┌────────────────────┐        │
│ │  Upload Resume     │    │  Profile Photo     │        │
│ │                    │    │    (Optional)      │        │
│ │                    │    │                    │        │
│ │                    │    │                    │        │
│ │                    │    │                    │        │
│ └────────────────────┘    └────────────────────┘        │
│                                                          │
│ ┌──────────────────────────────────────────────────────┐ │
│ │ [ Skip for now ]     [ Complete with Resume Only ]   │ │
│ │                      [ Continue to Preferences >  ]   │ │
│ └──────────────────────────────────────────────────────┘ │
├──────────────────────────────────────────────────────────┤
│ While only your resume is required, additional           │
│ information helps us find better matches. You can always │
│ update your preferences later from your profile settings.│
└──────────────────────────────────────────────────────────┘
```

## 2. Job Preferences Tab with Optional Fields

```
┌──────────────────────────────────────────────────────────┐
│ Tell us more about yourself                              │
│ Upload your resume to get started immediately.           │
│ Additional profile details are optional but help us      │
│ match you better.                                        │
├──────────────────────────────────────────────────────────┤
│ [ Resume & Photo ] [ Job Preferences ] [ Add. Criteria ] │
├──────────────────────────────────────────────────────────┤
│                                                          │
│ Job Titles You're Interested In (Optional)               │
│ ┌────────────────────────────────┐ ┌────────┐           │
│ │ e.g. Software Engineer         │ │  Add   │           │
│ └────────────────────────────────┘ └────────┘           │
│                                                          │
│ Salary Range (Optional)                                  │
│ $50,000 - $150,000                                       │
│ [====●==================================●=====]          │
│                                                          │
│ Preferred Location (Optional)                            │
│ ┌────────────────────────────────┐                       │
│ │ e.g. San Francisco, CA         │                       │
│ └────────────────────────────────┘                       │
│ □ Remote-only positions                                  │
│                                                          │
│ Industry (Optional)                                      │
│ ┌────────────────────────────────────────────┐           │
│ │ Select an industry                         ▼ │         │
│ └────────────────────────────────────────────┘           │
│                                                          │
│ Specialty/Niche (Optional)                               │
│ ┌────────────────────────────────────────────┐           │
│ │ e.g. Machine Learning, Front-end Dev       │           │
│ └────────────────────────────────────────────┘           │
│                                                          │
│ ┌──────────────────────────────────────────────────────┐ │
│ │ [ < Back ]                  [ Continue >  ]          │ │
│ └──────────────────────────────────────────────────────┘ │
├──────────────────────────────────────────────────────────┤
│ While only your resume is required, additional           │
│ information helps us find better matches. You can always │
│ update your preferences later from your profile settings.│
└──────────────────────────────────────────────────────────┘
```

## 3. Additional Criteria Tab with Optional Fields

```
┌──────────────────────────────────────────────────────────┐
│ Tell us more about yourself                              │
│ Upload your resume to get started immediately.           │
│ Additional profile details are optional but help us      │
│ match you better.                                        │
├──────────────────────────────────────────────────────────┤
│ [ Resume & Photo ] [ Job Preferences ] [ Add. Criteria ] │
├──────────────────────────────────────────────────────────┤
│                                                          │
│ Work Type (Optional)                                     │
│ ☑ Remote    ☑ Hybrid    ☐ On-site                        │
│                                                          │
│ Employment Type (Optional)                               │
│ ☑ Full-time     ☐ Part-time                              │
│ ☐ Contract      ☐ Internship                             │
│                                                          │
│ Education Level (Optional)                               │
│ ☐ High School       ☐ Associate's Degree                 │
│ ☑ Bachelor's Degree ☐ Master's Degree                    │
│ ☐ Doctorate         ☐ Professional Certificate           │
│                                                          │
│ Years of Experience (Optional)                           │
│ 5 years                                                  │
│ [=================●===========================]          │
│                                                          │
│ ┌──────────────────────────────────────────────────────┐ │
│ │ [ < Back ]            [ Save and Complete Profile ]  │ │
│ └──────────────────────────────────────────────────────┘ │
├──────────────────────────────────────────────────────────┤
│ While only your resume is required, additional           │
│ information helps us find better matches. You can always │
│ update your preferences later from your profile settings.│
└──────────────────────────────────────────────────────────┘
```