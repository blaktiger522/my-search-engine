"""
JobPulse - Advanced Job Search Platform
Copyright (c) 2025 JobPulse. All rights reserved.

This source code is protected by copyright law.
Unauthorized copying or use is strictly prohibited.
"""

from typing import List, Dict, Optional
from openai import OpenAI
import google.generativeai as genai
import os
import logging
import json
from dataclasses import dataclass
import aiohttp
import asyncio
import random

logger = logging.getLogger(__name__)

@dataclass
class JobMatch:
    title: str
    match_score: float
    skills_matched: List[str]
    recommendations: str

class AIService:
    def __init__(self):
        # Initialize all AI providers with equal status
        self.ai_providers = []

        # Initialize Gemini
        if os.getenv('GEMINI_API_KEY'):
            genai.configure(api_key=os.getenv('GEMINI_API_KEY'))
            self.gemini_model = genai.GenerativeModel('gemini-pro')
            self.ai_providers.append('gemini')
            logger.info("Gemini AI initialized successfully")
        else:
            self.gemini_model = None
            logger.warning("Gemini AI not initialized - API key missing")

        # Initialize DeepSeek
        if os.getenv('DEEPSEEK_API_KEY'):
            self.deepseek_api_key = os.getenv('DEEPSEEK_API_KEY')
            self.deepseek_api_url = "https://api.deepseek.ai/v1/completions"
            self.ai_providers.append('deepseek')
            logger.info("DeepSeek AI initialized successfully")
        else:
            self.deepseek_api_key = None
            logger.warning("DeepSeek AI not initialized - API key missing")

        # Initialize OpenAI
        if os.getenv('OPENAI_API_KEY'):
            self.openai_client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
            self.ai_providers.append('openai')
            logger.info("OpenAI initialized successfully")
        else:
            self.openai_client = None
            logger.warning("OpenAI not initialized - API key missing")

    async def _call_deepseek(self, system_prompt: str, user_prompt: str) -> Dict:
        """Make a call to DeepSeek API"""
        try:
            headers = {
                "Authorization": f"Bearer {self.deepseek_api_key}",
                "Content-Type": "application/json"
            }

            data = {
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                "model": "deepseek-chat",
                "temperature": 0.7,
                "max_tokens": 500
            }

            async with aiohttp.ClientSession() as session:
                async with session.post(self.deepseek_api_url, headers=headers, json=data) as response:
                    if response.status != 200:
                        raise Exception(f"DeepSeek API returned status {response.status}")
                    return await response.json()
        except Exception as e:
            logger.error(f"DeepSeek API error: {str(e)}")
            raise

    async def search_jobs(self, criteria: Dict) -> List[Dict]:
        """Search for jobs using AI-powered matching"""
        try:
            system_prompt = """You are a job search specialist. Search and filter jobs based on the given criteria.
            Consider skills, experience, location, and other relevant factors."""
            
            response = await self.get_ai_response(system_prompt, json.dumps(criteria))
            return json.loads(response['choices'][0]['message']['content'])
        except Exception as e:
            logger.error(f"Error searching jobs: {str(e)}")
            raise

    async def scan_resume(self, resume_text: str, job_description: str) -> Dict:
        """Scan and compare resume against job requirements"""
        try:
            system_prompt = """Analyze this resume against the job requirements.
            Identify matching skills, experience gaps, and provide a compatibility score."""
            
            user_prompt = f"Resume: {resume_text}\nJob Description: {job_description}"
            response = await self.get_ai_response(system_prompt, user_prompt)
            return json.loads(response['choices'][0]['message']['content'])
        except Exception as e:
            logger.error(f"Error scanning resume: {str(e)}")
            raise

    async def filter_jobs(self, jobs: List[Dict], filters: Dict) -> List[Dict]:
        """Apply AI-powered filtering to job results"""
        try:
            system_prompt = """Filter and rank these jobs based on the specified criteria.
            Consider relevance, match quality, and applicant preferences."""
            
            user_prompt = f"Jobs: {json.dumps(jobs)}\nFilters: {json.dumps(filters)}"
            response = await self.get_ai_response(system_prompt, user_prompt)
            return json.loads(response['choices'][0]['message']['content'])
        except Exception as e:
            logger.error(f"Error filtering jobs: {str(e)}")
            raise

    async def get_ai_response(self, system_prompt: str, user_prompt: str) -> Dict:
        """Get AI response from available providers with equal priority"""
        available_providers = []
        errors = []

        # Collect all available providers
        if self.gemini_model:
            available_providers.append("gemini")
        if self.deepseek_api_key:
            available_providers.append("deepseek")
        if self.openai_client:
            available_providers.append("openai")

        if not available_providers:
            raise Exception("No AI providers available")

        # Randomly select a provider for load balancing
        selected_provider = random.choice(available_providers)

        # Try the selected provider
        try:
            if selected_provider == "gemini":
                logger.info("Using Gemini AI")
                response = await self.gemini_model.generate_content(
                    f"{system_prompt}\n\n{user_prompt}"
                )
                return {
                    "choices": [{
                        "message": {
                            "content": response.text
                        }
                    }]
                }
            elif selected_provider == "deepseek":
                logger.info("Using DeepSeek")
                return await self._call_deepseek(system_prompt, user_prompt)
            elif selected_provider == "openai":
                logger.info("Using OpenAI")
                response = await self.openai_client.chat.completions.create(
                    model="gpt-4",
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    max_tokens=500
                )
                return {
                    "choices": [{
                        "message": {
                            "content": response.choices[0].message.content
                        }
                    }]
                }
        except Exception as e:
            logger.error(f"{selected_provider} API failed: {str(e)}")
            raise Exception(f"AI provider {selected_provider} failed: {str(e)}")
            try:
                logger.info("Attempting OpenAI API call as final fallback")
                response = await self.openai_client.chat.completions.create(
                    model="gpt-4",
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    max_tokens=500
                )
                return {
                    "choices": [{
                        "message": {
                            "content": response.choices[0].message.content
                        }
                    }]
                }
            except Exception as e:
                logger.warning(f"OpenAI API failed: {str(e)}")
                errors.append(f"OpenAI: {str(e)}")

        # If all providers fail, raise an error with details
        raise Exception(f"All AI providers failed: {'; '.join(errors)}")

    async def analyze_resume(self, resume_text: str) -> Dict:
        """Analyze resume using AI to extract skills and experience."""
        try:
            system_prompt = "You are an expert resume analyzer. Extract key skills, experience, and qualifications from the resume."
            response = await self.get_ai_response(system_prompt, resume_text)
            return json.loads(response['choices'][0]['message']['content'])
        except Exception as e:
            logger.error(f"Error analyzing resume: {str(e)}")
            raise

    async def match_jobs(self, job_description: Dict, user_profile: Dict) -> List[JobMatch]:
        """Use AI to match jobs with user profile."""
        try:
            system_prompt = "You are an expert job matcher. Analyze the match between user profile and job description."
            user_prompt = f"Profile: {json.dumps(user_profile)}\nJob: {json.dumps(job_description)}"

            response = await self.get_ai_response(system_prompt, user_prompt)
            matches_data = json.loads(response['choices'][0]['message']['content'])

            return [
                JobMatch(
                    title=match.get('title', ''),
                    match_score=match.get('match_score', 0.0),
                    skills_matched=match.get('skills_matched', []),
                    recommendations=match.get('recommendations', '')
                )
                for match in matches_data
            ]
        except Exception as e:
            logger.error(f"Error matching jobs: {str(e)}")
            raise

    async def generate_job_recommendations(self, user_profile: Dict) -> List[Dict]:
        """Generate personalized job recommendations based on user profile."""
        try:
            system_prompt = "You are a career advisor. Based on the user's profile, suggest relevant job opportunities."
            response = await self.get_ai_response(system_prompt, json.dumps(user_profile))
            return json.loads(response['choices'][0]['message']['content'])
        except Exception as e:
            logger.error(f"Error generating recommendations: {str(e)}")
            raise

# Initialize the AI service
ai_service = AIService()