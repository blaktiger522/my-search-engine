from flask import Flask, jsonify, request
from flask_cors import CORS
import os
import logging
from ai_service import ai_service

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
# Configure CORS to allow specific origin in development
CORS(app, resources={
    r"/api/*": {
        "origins": ["http://localhost:5000", "http://localhost:3000"],
        "methods": ["GET", "POST", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization"]
    }
})

# Configuration
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'pdf', 'docx'}

# Ensure the upload folder exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Function to check allowed file extensions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/api/health')
def health_check():
    logger.info("Health check endpoint called")
    return jsonify({"status": "healthy", "message": "Python backend is running!"})

# Resume Upload Endpoint with AI Analysis
@app.route('/api/upload', methods=['POST'])
async def upload_resume():
    try:
        if 'resume' not in request.files:
            logger.warning("No file part in the request")
            return jsonify({'error': 'No file part'}), 400

        file = request.files['resume']
        if file.filename == '':
            logger.warning("No selected file")
            return jsonify({'error': 'No selected file'}), 400

        if file and allowed_file(file.filename):
            # Save the file
            file_path = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(file_path)

            # Extract text from resume (implement text extraction based on file type)
            resume_text = "Example resume text"  # Replace with actual text extraction

            # Analyze resume using AI
            analysis = await ai_service.analyze_resume(resume_text)

            logger.info(f"Successfully analyzed resume: {file.filename}")
            return jsonify({
                'message': 'Resume uploaded and analyzed successfully',
                'analysis': analysis
            }), 200
        else:
            logger.warning(f"Invalid file type: {file.filename}")
            return jsonify({'error': 'File type not allowed'}), 400
    except Exception as e:
        logger.error(f"Error in upload_resume: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/api/chat', methods=['POST'])
async def chat():
    try:
        data = request.json
        if not data:
            logger.error("No data provided in request")
            return jsonify({'error': True, 'message': 'No data provided'}), 400

        user_message = data.get('message', '')
        personality = data.get('personality', 'human')

        if not user_message:
            logger.error("Message is required")
            return jsonify({'error': True, 'message': 'Message is required'}), 400

        logger.info(f"Processing chat message with {personality} personality")

        response = await ai_service.get_ai_response(
            f"""You are a unique AI assistant with dual personality:
            1. Human side: Warm, empathetic, uses casual language, and shows emotion
            2. Robot side: Logical, precise, uses technical terms, and maintains professional distance

            Currently operating in: {personality.upper()} mode.
            Use the appropriate personality in your response.
            Start your response with [{personality.upper()}] to indicate the personality.
            Keep responses concise and focused on job search and career advice.""",
            user_message
        )

        ai_response = response['choices'][0]['message']['content']
        logger.info("Successfully generated AI response")

        return jsonify({
            'error': False,
            'response': ai_response,
            'personality': personality
        }), 200

    except Exception as e:
        logger.error(f"Error in chat endpoint: {str(e)}")
        return jsonify({
            'error': True,
            'message': 'Failed to process chat message'
        }), 500

if __name__ == '__main__':
    port = int(os.environ.get("PORT", 5000))
    logger.info(f"Starting Flask server on port {port}")
    app.run(host='0.0.0.0', port=port)