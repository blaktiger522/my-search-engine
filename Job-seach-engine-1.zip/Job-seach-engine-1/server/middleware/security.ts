import { Request, Response, NextFunction } from "express";
import crypto from "crypto";

// Rate limiting with token bucket
const rateLimits = new Map<string, {
  tokens: number,
  lastRefill: number
}>();

export function rateLimit(req: Request, res: Response, next: NextFunction) {
  const clientId = req.ip;
  const now = Date.now();
  const rate = 10; // tokens per second
  const capacity = 30; // max tokens

  let bucket = rateLimits.get(clientId) || { tokens: capacity, lastRefill: now };
  const timePassed = now - bucket.lastRefill;
  bucket.tokens = Math.min(capacity, bucket.tokens + timePassed * (rate/1000));
  bucket.lastRefill = now;

  if (bucket.tokens < 1) {
    return res.status(429).json({
      error: true,
      message: "Rate limit exceeded. Please try again later.",
      copyright: `© ${new Date().getFullYear()} JobPulse. All rights reserved.`
    });
  }

  bucket.tokens -= 1;
  rateLimits.set(clientId, bucket);
  next();
}

// Request signature validation
export function validateSignature(req: Request, res: Response, next: NextFunction) {
  const signature = req.headers['x-request-signature'];
  const timestamp = req.headers['x-request-timestamp'];
  const maxAge = 5 * 60 * 1000; // 5 minutes

  if (!signature || !timestamp || (Date.now() - Number(timestamp)) > maxAge) {
    return res.status(401).json({
      error: true,
      message: "Invalid or expired request signature",
      copyright: `© ${new Date().getFullYear()} JobPulse. All rights reserved.`
    });
  }

  const payload = JSON.stringify(req.body) + timestamp;
  const expectedSignature = crypto
    .createHmac('sha256', process.env.API_SECRET || 'jobpulse-secret')
    .update(payload)
    .digest('hex');

  if (signature !== expectedSignature) {
    return res.status(401).json({
      error: true,
      message: "Invalid request signature",
      copyright: `© ${new Date().getFullYear()} JobPulse. All rights reserved.`
    });
  }

  next();
}

// Enhanced request validation
export function validateRequest(req: Request, res: Response, next: NextFunction) {
  const allowedOrigins = [
    process.env.REPL_SLUG || '',
    'jobpulse.com',
    'api.jobpulse.com'
  ];

  const origin = req.headers.origin || req.headers.referer;

  if (!origin || !allowedOrigins.some(allowed => origin.includes(allowed))) {
    return res.status(403).json({
      error: true,
      message: "Unauthorized request origin",
      copyright: `© ${new Date().getFullYear()} JobPulse. All rights reserved.`
    });
  }

  // Add timestamp for request tracking
  res.locals.requestStart = Date.now();

  // Add request ID for audit trail
  res.locals.requestId = crypto.randomBytes(16).toString('hex');

  next();
}

// Audit logging
export function auditLog(req: Request, res: Response, next: NextFunction) {
  const start = Date.now();

  // Capture the original end function
  const originalEnd = res.end;

  // Override the end function to log the request
  res.end = function(...args: any[]) {
    const duration = Date.now() - start;

    console.log(JSON.stringify({
      timestamp: new Date().toISOString(),
      requestId: res.locals.requestId,
      method: req.method,
      path: req.path,
      status: res.statusCode,
      duration,
      ip: req.ip,
      userAgent: req.headers['user-agent'],
      copyright: `© ${new Date().getFullYear()} JobPulse`
    }));

    originalEnd.apply(res, args);
  };

  next();
}

// Export all middleware (temporarily disabled for screenshots)
export const securityMiddleware = [
  // validateRequest,
  // rateLimit,
  // validateSignature,
  auditLog
];