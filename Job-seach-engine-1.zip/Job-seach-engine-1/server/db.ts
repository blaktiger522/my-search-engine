import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";

neonConfig.webSocketConstructor = ws;

// Add retry logic and better error handling
async function createDatabaseConnection(retries = 3, delay = 2000) {
  for (let i = 0; i < retries; i++) {
    try {
      const pool = new Pool({ 
        connectionString: process.env.DATABASE_URL,
        connectionTimeoutMillis: 5000, // 5 second timeout
        maxConnections: 20
      });

      // Test the connection
      await pool.query('SELECT 1');
      console.log('Successfully connected to PostgreSQL database');

      return drizzle(pool, { schema });
    } catch (error) {
      console.error(`Database connection attempt ${i + 1} failed:`, error);

      if (i < retries - 1) {
        console.log(`Retrying in ${delay/1000} seconds...`);
        await new Promise(resolve => setTimeout(resolve, delay));
      } else {
        console.error('All database connection attempts failed');
        // Don't throw, return undefined to allow app to run without DB
        return undefined;
      }
    }
  }
}

// Export a promise that resolves to the database connection
export const dbConnection = createDatabaseConnection();

// Export the db object that awaits the connection
export const db = dbConnection.then(connection => {
  console.log('Database connection and schema initialized');
  return connection;
}).catch(error => {
  console.error('Failed to initialize database:', error);
  // Return undefined instead of throwing to allow app to run without DB
  return undefined;
});