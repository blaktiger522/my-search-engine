/**
 * JobPulse - Advanced Job Search Platform
 * Copyright (c) 2025 JobPulse. All rights reserved.
 * 
 * This source code is protected by copyright law.
 * Unauthorized copying or use is strictly prohibited.
 */

import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { db } from "./db";
import { users } from "@shared/schema";
import { count } from "drizzle-orm";
import crypto from "crypto";

// Enhanced copyright protection middleware
function validateProtectedRequest(req: any, res: any, next: any) {
  // Check required headers
  const protectedHeader = req.headers['x-jobpulse-protected'];
  const apiVersion = req.headers['x-api-version'];
  const clientId = req.headers['x-client-id'];
  const referrer = req.headers.referer;

  // Validate all required headers
  if (!protectedHeader || !apiVersion || !clientId || !referrer?.includes(process.env.REPL_SLUG || '')) {
    return res.status(403).json({
      error: true,
      message: "Unauthorized access. This API is protected by copyright law.",
      required: ['x-jobpulse-protected', 'x-api-version', 'x-client-id']
    });
  }

  // Validate API version
  const supportedVersions = ['1.0', '1.1', '2.0'];
  if (!supportedVersions.includes(apiVersion)) {
    return res.status(400).json({
      error: true,
      message: "Unsupported API version. Please upgrade your client.",
      supportedVersions
    });
  }

  // Add request verification token
  const verificationToken = crypto.randomBytes(32).toString('hex');
  res.locals.verificationToken = verificationToken;

  next();
}

export function registerRoutes(app: Express): Server {
  // Temporarily disable enhanced protection for screenshots
  // app.use('/api', validateProtectedRequest);

  // Consolidated statistics endpoint with enhanced protection
  app.get("/api/statistics", async (req, res) => {
    try {
      // Get users count
      const userCount = await db.select({ value: count() }).from(users);

      const statistics = {
        database: {
          users: {
            total: userCount[0].value,
            active: userCount[0].value,
            lastEntry: await db.select().from(users).orderBy(users.id).limit(1),
          }
        },
        system: {
          lastUpdated: new Date().toISOString(),
          storage: {
            type: "PostgreSQL",
            status: "Active",
            lastBackup: new Date().toISOString()
          },
          aiProviders: [
            { name: "OpenAI", status: "active", type: "chat and search", usage: "active" },
            { name: "Gemini", status: "active", type: "chat and search", usage: "active" },
            { name: "DeepSeek", status: "active", type: "chat and search", usage: "active" }
          ],
          activeServices: {
            jobMatching: true,
            resumeAnalysis: true,
            chatbot: true
          }
        },
        _verificationToken: res.locals.verificationToken
      };

      // Add enhanced copyright protection
      res.setHeader('X-Protected-By', 'JobPulse Copyright Protection');
      res.setHeader('X-Request-Verified', res.locals.verificationToken);
      res.json(statistics);
    } catch (error) {
      console.error("Statistics API Error:", error);
      res.status(500).json({ 
        error: true,
        message: "Failed to fetch statistics"
      });
    }
  });

  app.post("/api/jobs/search", async (req, res) => {
    try {
      const { criteria } = req.body;
      const jobs = await storage.ai_service.search_jobs(criteria);
      res.json({ error: false, jobs });
    } catch (error) {
      console.error("Job search error:", error);
      res.status(500).json({ error: true, message: "Failed to search jobs" });
    }
  });

  app.post("/api/jobs/scan", async (req, res) => {
    try {
      const { resume, jobDescription } = req.body;
      const analysis = await storage.ai_service.scan_resume(resume, jobDescription);
      res.json({ error: false, analysis });
    } catch (error) {
      console.error("Resume scan error:", error);
      res.status(500).json({ error: true, message: "Failed to scan resume" });
    }
  });

  app.post("/api/jobs/filter", async (req, res) => {
    try {
      const { jobs, filters } = req.body;
      const filtered = await storage.ai_service.filter_jobs(jobs, filters);
      res.json({ error: false, jobs: filtered });
    } catch (error) {
      console.error("Job filter error:", error);
      res.status(500).json({ error: true, message: "Failed to filter jobs" });
    }
  });

  app.post("/api/chat", async (req, res) => {
    try {
      const { message } = req.body;

      if (!message) {
        return res.status(400).json({ 
          error: true,
          message: "Message is required" 
        });
      }

      // Enhanced rate limiting with sliding window
      const now = Date.now();
      const windowSize = 60000; // 1 minute
      const maxRequests = 60; // 60 requests per minute

      const requestHistory = req.session.requestHistory || [];
      const recentRequests = requestHistory.filter(time => now - time < windowSize);

      if (recentRequests.length >= maxRequests) {
        return res.status(429).json({
          error: true,
          message: "Rate limit exceeded. Please wait before trying again.",
          retryAfter: Math.ceil((recentRequests[0] + windowSize - now) / 1000)
        });
      }

      recentRequests.push(now);
      req.session.requestHistory = recentRequests;

      // Delegate chat handling to AI service with enhanced verification
      const response = await storage.handleChatMessage(message);

      // Add enhanced copyright protection and verification
      res.setHeader('X-Protected-By', 'JobPulse Copyright Protection');
      res.setHeader('X-Request-Verified', res.locals.verificationToken);
      res.json({ 
        error: false, 
        message: response,
        _verificationToken: res.locals.verificationToken
      });
    } catch (error: any) {
      console.error("Chat API Error:", error);

      if (error?.status === 429) {
        return res.status(429).json({ 
          error: true,
          message: "AI service is temporarily unavailable. Please try again later."
        });
      }

      res.status(500).json({ 
        error: true,
        message: "Failed to process your request. Please try again."
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}