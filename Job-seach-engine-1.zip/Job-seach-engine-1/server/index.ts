/**
 * JobPulse - Advanced Job Search Platform
 * Copyright (c) 2025 JobPulse. All rights reserved.
 * 
 * This source code is protected by copyright law.
 * Unauthorized copying or use is strictly prohibited.
 */

import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { dbConnection } from "./db";
import { users } from "@shared/schema";
import { setupAuth } from "./auth";
import { securityMiddleware } from "./middleware/security";
import * as crypto from 'crypto';

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Copyright protection header only since security headers are in middleware
app.use((req, res, next) => {
  res.setHeader('X-Protected-By', 'JobPulse Copyright Protection');

  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    if (typeof bodyJson === 'object' && bodyJson !== null) {
      bodyJson.copyright = `© ${new Date().getFullYear()} JobPulse. All rights reserved.`;
      // Add digital signature to response
      const signature = crypto
        .createHmac('sha256', process.env.API_SECRET || 'jobpulse-secret')
        .update(JSON.stringify(bodyJson))
        .digest('hex');
      bodyJson._signature = signature;
    }
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      log(logLine);
    }
  });

  next();
});

// Apply enhanced security middleware
app.use('/api', securityMiddleware);

// Initialize server and handle startup gracefully
async function initializeServer() {
  try {
    log("Starting server initialization...");

    // Set up auth first to avoid session store dependency issues
    setupAuth(app);
    log("Authentication setup complete");

    // Register routes before database check to allow static content
    const server = registerRoutes(app);
    log("Routes registered");

    // Set up error handling
    app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
      const status = err.status || err.statusCode || 500;
      const message = err.message || "Internal Server Error";
      res.status(status).json({ 
        message,
        copyright: `© ${new Date().getFullYear()} JobPulse. All rights reserved.`
      });
      console.error(err);
    });

    // Configure static file serving or Vite based on environment
    if (app.get("env") === "development") {
      await setupVite(app, server);
      log("Vite development server initialized");
    } else {
      serveStatic(app);
      log("Static file serving configured");
    }

    // Start listening before database connection to avoid timeouts
    const PORT = process.env.PORT || 5000;
    server.listen(PORT, () => {
      log(`Server successfully started and listening on port ${PORT}`);
    });

    // Connect to database after server is running
    try {
      const db = await dbConnection;
      log("Database connection established");

      // Test database access but don't block startup
      db?.select().from(users).limit(1).then(() => {
        log("Database schema verified");
      }).catch((error) => {
        log("Database schema verification failed:", error);
      });
    } catch (error) {
      log("Database connection failed, but server will continue running:", error);
    }

  } catch (error) {
    console.error("Failed to initialize server:", error);
    // Don't exit process, let the error handler deal with it
    log("Server initialization encountered errors but will attempt to continue");
  }
}

// Start the server
initializeServer();