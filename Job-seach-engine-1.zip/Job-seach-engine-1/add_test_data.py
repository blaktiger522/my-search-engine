
import os
import psycopg2
from urllib.parse import urlparse

# Get database connection string from environment
db_url = os.getenv('DATABASE_URL')
if not db_url:
    print("No DATABASE_URL environment variable found")
    exit(1)

# Parse the connection URL
result = urlparse(db_url)
username = result.username
password = result.password
database = result.path[1:]
hostname = result.hostname
port = result.port

# Connect to database
conn = psycopg2.connect(
    database = database,
    user = username,
    password = password,
    host = hostname,
    port = port
)

cursor = conn.cursor()

# Create test user
cursor.execute("""
    INSERT INTO users (name, email) 
    VALUES ('Test User', 'test@example.com')
    RETURNING id;
""")

conn.commit()
print("Test data added successfully")
conn.close()
