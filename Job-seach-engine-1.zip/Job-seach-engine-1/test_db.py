
from replit import db

# Add test data
db["test_key"] = "test_value"

# Print all keys
print("Database keys:")
for key in db.keys():
    print(f"{key}: {db[key]}")
