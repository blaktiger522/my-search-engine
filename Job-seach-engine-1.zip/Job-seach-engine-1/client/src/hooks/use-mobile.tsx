import * as React from "react";

// Device breakpoints
const MOBILE_BREAKPOINT = 768;
const TABLET_BREAKPOINT = 1024;

// Device types
export type DeviceType = 'mobile' | 'tablet' | 'desktop';

export function useDeviceDetection() {
  const [deviceInfo, setDeviceInfo] = React.useState<{
    isMobile: boolean;
    isTablet: boolean;
    isDesktop: boolean;
    deviceType: DeviceType;
    orientation: 'portrait' | 'landscape';
    screenWidth: number;
    touchDevice: boolean;
  }>({
    isMobile: false,
    isTablet: false, 
    isDesktop: true,
    deviceType: 'desktop',
    orientation: 'landscape',
    screenWidth: typeof window !== 'undefined' ? window.innerWidth : 1200,
    touchDevice: false
  });

  React.useEffect(() => {
    // Detect touch capability
    const isTouchDevice = () => {
      return 'ontouchstart' in window || 
        navigator.maxTouchPoints > 0 ||
        (navigator as any).msMaxTouchPoints > 0;
    };

    // Determine device type based on screen size and user agent
    const determineDeviceType = (): DeviceType => {
      const width = window.innerWidth;
      const userAgent = navigator.userAgent.toLowerCase();

      const isMobileByAgent = /android|webos|iphone|ipad|ipod|blackberry|windows phone/i.test(userAgent);

      if (width < MOBILE_BREAKPOINT || isMobileByAgent) {
        return 'mobile';
      } else if (width < TABLET_BREAKPOINT) {
        return 'tablet';
      } else {
        return 'desktop';
      }
    };

    // Get current orientation
    const getOrientation = () => {
      return window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
    };

    // Update device info
    const updateDeviceInfo = () => {
      const deviceType = determineDeviceType();
      const width = window.innerWidth;

      const newDeviceInfo = {
        isMobile: deviceType === 'mobile',
        isTablet: deviceType === 'tablet',
        isDesktop: deviceType === 'desktop',
        deviceType,
        orientation: getOrientation(),
        screenWidth: width,
        touchDevice: isTouchDevice()
      };

      // Only update if there's an actual change
      if (JSON.stringify(deviceInfo) !== JSON.stringify(newDeviceInfo)) {
        setDeviceInfo(newDeviceInfo);
      }
    };

    // Initial detection
    updateDeviceInfo();

    // Set up listeners for screen size changes
    const handleResize = () => {
      const newWidth = window.innerWidth;
      if (newWidth !== deviceInfo.screenWidth) {
        updateDeviceInfo();
      }
    };

    // Set up listeners for orientation changes
    const handleOrientationChange = () => {
      updateDeviceInfo();
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleOrientationChange);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleOrientationChange);
    };
  }, []);

  return deviceInfo;
}

// For backward compatibility
export function useIsMobile() {
  const { isMobile } = useDeviceDetection();
  return isMobile;
}