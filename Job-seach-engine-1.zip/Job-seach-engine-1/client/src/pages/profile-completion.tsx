/**
 * JobPulse - Advanced Job Search Platform
 * Copyright (c) 2025 JobPulse. All rights reserved.
 * 
 * This source code is protected by copyright law.
 * Unauthorized copying or use is strictly prohibited.
 */
import { useState } from "react";
import { useLocation } from "wouter";
import { 
  ArrowRight, 
  Upload, 
  Camera, 
  Briefcase, 
  DollarSign, 
  MapPin, 
  Building, 
  Star, 
  Clock, 
  GraduationCap,
  Save,
  Loader2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useAuth } from "@/hooks/use-auth";
import { useDeviceDetection } from "@/hooks/use-mobile";

// Job preference types
type WorkType = 'remote' | 'hybrid' | 'on-site';
type EmploymentType = 'full-time' | 'part-time' | 'contract' | 'internship';

export default function ProfileCompletion() {
  const [, setLocationPath] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  const { isMobile } = useDeviceDetection();
  const [activeTab, setActiveTab] = useState("resume");
  const [submitting, setSubmitting] = useState(false);
  
  // Resume state
  const [resumeFile, setResumeFile] = useState<File | null>(null);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [resumePreview, setResumePreview] = useState("");
  const [photoPreview, setPhotoPreview] = useState("");
  
  // Job criteria state
  const [jobTitles, setJobTitles] = useState<string[]>([]);
  const [salaryRange, setSalaryRange] = useState([50000, 100000]);
  const [location, setLocation] = useState("");
  const [remoteOnly, setRemoteOnly] = useState(false);
  const [industryField, setIndustryField] = useState("");
  const [specialty, setSpecialty] = useState("");
  const [workTypes, setWorkTypes] = useState<WorkType[]>([]);
  const [employmentTypes, setEmploymentTypes] = useState<EmploymentType[]>([]);
  const [educationLevels, setEducationLevels] = useState<string[]>([]);
  const [jobTitle, setJobTitle] = useState("");
  const [yearsOfExperience, setYearsOfExperience] = useState(0);
  
  // Handle resume file upload
  const handleResumeUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      
      // Check file size (10MB max)
      const maxSizeBytes = 10 * 1024 * 1024; // 10MB in bytes
      if (file.size > maxSizeBytes) {
        toast({
          variant: "destructive",
          title: "File too large",
          description: "Please upload a resume smaller than 10MB.",
        });
        return;
      }
      
      setResumeFile(file);
      
      // For PDF, we just show the file name
      if (file.type === "application/pdf") {
        setResumePreview(file.name);
      } else {
        // For other formats, show a generic preview
        setResumePreview(file.name);
      }
      
      toast({
        title: "Resume uploaded",
        description: "Your resume has been uploaded successfully.",
      });
    }
  };
  
  // Handle photo upload
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      
      // Check file size (10MB max)
      const maxSizeBytes = 10 * 1024 * 1024; // 10MB in bytes
      if (file.size > maxSizeBytes) {
        toast({
          variant: "destructive",
          title: "File too large",
          description: "Please upload an image smaller than 10MB.",
        });
        return;
      }
      
      setPhotoFile(file);
      
      // Create an image preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
      
      toast({
        title: "Photo uploaded",
        description: "Your photo has been uploaded successfully.",
      });
    }
  };
  
  // Handle job title input
  const handleAddJobTitle = () => {
    if (jobTitle && !jobTitles.includes(jobTitle)) {
      setJobTitles([...jobTitles, jobTitle]);
      setJobTitle("");
    }
  };
  
  // Handle work type toggle
  const handleWorkTypeToggle = (type: WorkType) => {
    if (workTypes.includes(type)) {
      setWorkTypes(workTypes.filter(t => t !== type));
    } else {
      setWorkTypes([...workTypes, type]);
    }
  };
  
  // Handle employment type toggle
  const handleEmploymentTypeToggle = (type: EmploymentType) => {
    if (employmentTypes.includes(type)) {
      setEmploymentTypes(employmentTypes.filter(t => t !== type));
    } else {
      setEmploymentTypes([...employmentTypes, type]);
    }
  };
  
  // Handle education level toggle
  const handleEducationLevelToggle = (level: string) => {
    if (educationLevels.includes(level)) {
      setEducationLevels(educationLevels.filter(l => l !== level));
    } else {
      setEducationLevels([...educationLevels, level]);
    }
  };
  
  // Submit profile data
  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      // Here we would typically upload files and save profile data to backend
      
      // Mock API call for demonstration
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      toast({
        title: "Profile completed!",
        description: "Your profile has been set up successfully.",
      });
      
      // Redirect to dashboard
      setLocationPath('/');
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to save your profile. Please try again.",
      });
    } finally {
      setSubmitting(false);
    }
  };
  
  // Skip profile completion
  const handleSkip = () => {
    toast({
      title: "Profile setup skipped",
      description: "You can complete your profile later from your account settings.",
    });
    setLocationPath('/');
  };
  
  // Format currency for salary display
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(value);
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-gray-50 py-10 px-4">
      <div className="container mx-auto max-w-4xl">
        <div className="text-center mb-8 animate-fade-in">
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
            Complete Your Profile
          </h1>
          <p className="text-muted-foreground mt-2">
            Help us personalize your job search experience
          </p>
        </div>
        
        <Card className="shadow-lg animate-slide-up">
          <CardHeader>
            <CardTitle>Tell us more about yourself</CardTitle>
            <CardDescription>
              Upload your resume to get started immediately. Additional profile details are optional but help us match you better.
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid grid-cols-2 md:grid-cols-3 w-full">
                <TabsTrigger value="resume" className="flex items-center gap-2">
                  <Upload className="h-4 w-4" />
                  <span className={isMobile ? "sr-only" : ""}>Resume & Photo</span>
                </TabsTrigger>
                <TabsTrigger value="preferences" className="flex items-center gap-2">
                  <Briefcase className="h-4 w-4" />
                  <span className={isMobile ? "sr-only" : ""}>Job Preferences</span>
                </TabsTrigger>
                <TabsTrigger value="criteria" className="flex items-center gap-2">
                  <Star className="h-4 w-4" />
                  <span className={isMobile ? "sr-only" : ""}>Additional Criteria</span>
                </TabsTrigger>
              </TabsList>
              
              {/* Resume & Photo Upload */}
              <TabsContent value="resume" className="space-y-6 mt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Resume Upload */}
                  <div className="space-y-3">
                    <Label htmlFor="resume">Upload Your Resume</Label>
                    <div 
                      className="border-2 border-dashed rounded-lg p-6 text-center hover:bg-gray-50 transition-colors cursor-pointer"
                      onClick={() => document.getElementById('resume')?.click()}
                    >
                      <input
                        id="resume"
                        type="file"
                        accept=".pdf,.doc,.docx,.txt"
                        className="hidden"
                        onChange={handleResumeUpload}
                      />
                      <div className="flex flex-col items-center justify-center space-y-2">
                        <Upload className="h-10 w-10 text-muted-foreground" />
                        {resumePreview ? (
                          <p className="font-medium text-primary">{resumePreview}</p>
                        ) : (
                          <>
                            <p className="font-medium">Upload Resume</p>
                            <p className="text-xs text-muted-foreground">
                              PDF, DOC, DOCX or TXT (Max 10MB)
                            </p>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  {/* Photo Upload */}
                  <div className="space-y-3">
                    <Label htmlFor="photo">Profile Photo (Optional)</Label>
                    <div 
                      className="border-2 border-dashed rounded-lg p-6 text-center hover:bg-gray-50 transition-colors cursor-pointer h-[180px] flex items-center justify-center"
                      onClick={() => document.getElementById('photo')?.click()}
                    >
                      <input
                        id="photo"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handlePhotoUpload}
                      />
                      
                      {photoPreview ? (
                        <img 
                          src={photoPreview} 
                          alt="Profile Preview" 
                          className="max-h-[140px] max-w-full object-contain rounded-md" 
                        />
                      ) : (
                        <div className="flex flex-col items-center justify-center space-y-2">
                          <Camera className="h-10 w-10 text-muted-foreground" />
                          <p className="font-medium">Upload Photo</p>
                          <p className="text-xs text-muted-foreground">
                            JPG, PNG or GIF (Max 10MB)
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-between pt-4">
                  <Button 
                    variant="outline" 
                    onClick={handleSkip}
                  >
                    Skip for now
                  </Button>
                  <div className="flex space-x-2">
                    <Button 
                      variant={resumeFile ? "default" : "outline"}
                      disabled={!resumeFile}
                      onClick={handleSubmit}
                    >
                      {submitting ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          Complete with Resume Only
                          <Save className="ml-2 h-4 w-4" />
                        </>
                      )}
                    </Button>
                    <Button 
                      onClick={() => setActiveTab("preferences")}
                    >
                      Continue to Preferences <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </TabsContent>
              
              {/* Job Preferences */}
              <TabsContent value="preferences" className="space-y-6 mt-6">
                {/* Job Titles */}
                <div className="space-y-3">
                  <Label htmlFor="jobTitle">Job Titles You're Interested In (Optional)</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="jobTitle"
                      placeholder="e.g. Software Engineer"
                      value={jobTitle}
                      onChange={(e) => setJobTitle(e.target.value)}
                    />
                    <Button 
                      type="button" 
                      onClick={handleAddJobTitle}
                      variant="outline"
                    >
                      Add
                    </Button>
                  </div>
                  
                  {jobTitles.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {jobTitles.map((title, index) => (
                        <div 
                          key={index} 
                          className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm flex items-center"
                        >
                          {title}
                          <button
                            type="button"
                            className="ml-2 text-primary/70 hover:text-primary"
                            onClick={() => setJobTitles(jobTitles.filter((_, i) => i !== index))}
                          >
                            ×
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                
                {/* Salary Range */}
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <Label>Salary Range (Optional)</Label>
                    <span className="text-sm font-medium">
                      {formatCurrency(salaryRange[0])} - {formatCurrency(salaryRange[1])}
                    </span>
                  </div>
                  <Slider
                    defaultValue={salaryRange}
                    max={300000}
                    min={0}
                    step={5000}
                    onValueChange={(value) => setSalaryRange(value as [number, number])}
                    className="py-4"
                  />
                </div>
                
                {/* Location */}
                <div className="space-y-3">
                  <Label htmlFor="location">Preferred Location (Optional)</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      id="location"
                      placeholder="e.g. San Francisco, CA"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                    />
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="remoteOnly"
                        checked={remoteOnly}
                        onCheckedChange={(checked) => setRemoteOnly(checked as boolean)}
                      />
                      <label
                        htmlFor="remoteOnly"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Remote-only positions
                      </label>
                    </div>
                  </div>
                </div>
                
                {/* Industry Field */}
                <div className="space-y-3">
                  <Label htmlFor="industry">Industry (Optional)</Label>
                  <Select
                    value={industryField}
                    onValueChange={setIndustryField}
                  >
                    <SelectTrigger id="industry">
                      <SelectValue placeholder="Select an industry" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="technology">Technology</SelectItem>
                      <SelectItem value="healthcare">Healthcare</SelectItem>
                      <SelectItem value="finance">Finance</SelectItem>
                      <SelectItem value="education">Education</SelectItem>
                      <SelectItem value="retail">Retail</SelectItem>
                      <SelectItem value="manufacturing">Manufacturing</SelectItem>
                      <SelectItem value="media">Media & Entertainment</SelectItem>
                      <SelectItem value="consulting">Consulting</SelectItem>
                      <SelectItem value="nonprofit">Non-profit</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                {/* Specialty */}
                <div className="space-y-3">
                  <Label htmlFor="specialty">Specialty/Niche (Optional)</Label>
                  <Input
                    id="specialty"
                    placeholder="e.g. Machine Learning, Front-end Development"
                    value={specialty}
                    onChange={(e) => setSpecialty(e.target.value)}
                  />
                </div>
                
                <div className="flex justify-between pt-4">
                  <Button 
                    variant="outline" 
                    onClick={() => setActiveTab("resume")}
                  >
                    Back
                  </Button>
                  <Button 
                    onClick={() => setActiveTab("criteria")}
                  >
                    Continue <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </TabsContent>
              
              {/* Additional Criteria */}
              <TabsContent value="criteria" className="space-y-6 mt-6">
                {/* Work Type */}
                <div className="space-y-3">
                  <Label>Work Type (Optional)</Label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="remote"
                        checked={workTypes.includes('remote')}
                        onCheckedChange={() => handleWorkTypeToggle('remote')}
                      />
                      <label
                        htmlFor="remote"
                        className="text-sm font-medium leading-none"
                      >
                        Remote
                      </label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="hybrid"
                        checked={workTypes.includes('hybrid')}
                        onCheckedChange={() => handleWorkTypeToggle('hybrid')}
                      />
                      <label
                        htmlFor="hybrid"
                        className="text-sm font-medium leading-none"
                      >
                        Hybrid
                      </label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="onsite"
                        checked={workTypes.includes('on-site')}
                        onCheckedChange={() => handleWorkTypeToggle('on-site')}
                      />
                      <label
                        htmlFor="onsite"
                        className="text-sm font-medium leading-none"
                      >
                        On-site
                      </label>
                    </div>
                  </div>
                </div>
                
                {/* Employment Type */}
                <div className="space-y-3">
                  <Label>Employment Type (Optional)</Label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="fullTime"
                        checked={employmentTypes.includes('full-time')}
                        onCheckedChange={() => handleEmploymentTypeToggle('full-time')}
                      />
                      <label
                        htmlFor="fullTime"
                        className="text-sm font-medium leading-none"
                      >
                        Full-time
                      </label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="partTime"
                        checked={employmentTypes.includes('part-time')}
                        onCheckedChange={() => handleEmploymentTypeToggle('part-time')}
                      />
                      <label
                        htmlFor="partTime"
                        className="text-sm font-medium leading-none"
                      >
                        Part-time
                      </label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="contract"
                        checked={employmentTypes.includes('contract')}
                        onCheckedChange={() => handleEmploymentTypeToggle('contract')}
                      />
                      <label
                        htmlFor="contract"
                        className="text-sm font-medium leading-none"
                      >
                        Contract
                      </label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="internship"
                        checked={employmentTypes.includes('internship')}
                        onCheckedChange={() => handleEmploymentTypeToggle('internship')}
                      />
                      <label
                        htmlFor="internship"
                        className="text-sm font-medium leading-none"
                      >
                        Internship
                      </label>
                    </div>
                  </div>
                </div>
                
                {/* Education Level */}
                <div className="space-y-3">
                  <Label>Education Level (Optional)</Label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="highSchool"
                        checked={educationLevels.includes('High School')}
                        onCheckedChange={() => handleEducationLevelToggle('High School')}
                      />
                      <label
                        htmlFor="highSchool"
                        className="text-sm font-medium leading-none"
                      >
                        High School
                      </label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="associate"
                        checked={educationLevels.includes('Associate')}
                        onCheckedChange={() => handleEducationLevelToggle('Associate')}
                      />
                      <label
                        htmlFor="associate"
                        className="text-sm font-medium leading-none"
                      >
                        Associate's Degree
                      </label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="bachelor"
                        checked={educationLevels.includes('Bachelor')}
                        onCheckedChange={() => handleEducationLevelToggle('Bachelor')}
                      />
                      <label
                        htmlFor="bachelor"
                        className="text-sm font-medium leading-none"
                      >
                        Bachelor's Degree
                      </label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="master"
                        checked={educationLevels.includes('Master')}
                        onCheckedChange={() => handleEducationLevelToggle('Master')}
                      />
                      <label
                        htmlFor="master"
                        className="text-sm font-medium leading-none"
                      >
                        Master's Degree
                      </label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="doctorate"
                        checked={educationLevels.includes('Doctorate')}
                        onCheckedChange={() => handleEducationLevelToggle('Doctorate')}
                      />
                      <label
                        htmlFor="doctorate"
                        className="text-sm font-medium leading-none"
                      >
                        Doctorate
                      </label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="certificate"
                        checked={educationLevels.includes('Certificate')}
                        onCheckedChange={() => handleEducationLevelToggle('Certificate')}
                      />
                      <label
                        htmlFor="certificate"
                        className="text-sm font-medium leading-none"
                      >
                        Professional Certificate
                      </label>
                    </div>
                  </div>
                </div>
                
                {/* Years of Experience */}
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <Label>Years of Experience (Optional)</Label>
                    <span className="text-sm font-medium">{yearsOfExperience} years</span>
                  </div>
                  <Slider
                    defaultValue={[yearsOfExperience]}
                    max={20}
                    min={0}
                    step={1}
                    onValueChange={(value) => setYearsOfExperience(value[0])}
                    className="py-4"
                  />
                </div>
                
                <div className="flex justify-between pt-4">
                  <Button 
                    variant="outline" 
                    onClick={() => setActiveTab("preferences")}
                  >
                    Back
                  </Button>
                  <Button 
                    onClick={handleSubmit}
                    disabled={submitting}
                  >
                    {submitting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        Save and Complete Profile
                        <Save className="ml-2 h-4 w-4" />
                      </>
                    )}
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
          
          <CardFooter className="flex justify-center border-t pt-6">
            <p className="text-sm text-muted-foreground text-center max-w-md">
              While only your resume is required, additional information helps us find better matches.
              You can always update your preferences later from your profile settings.
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}