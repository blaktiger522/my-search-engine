import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  ArrowRight,
  Loader2,
  ChevronDown,
  ChevronUp,
  FileText,
  Search,
  PenTool,
  MousePointer,
  Plane,
  Calculator,
  Mail,
  Briefcase,
  Github,
  Linkedin,
  Twitter,
  Menu,
  Info,
  LogIn,
  X
} from "lucide-react";
import { useLocation } from "wouter";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { useDeviceDetection } from "@/hooks/use-mobile";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis } from "recharts";

export default function Home() {
  const [loading, setLoading] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Get device information
  const deviceInfo = useDeviceDetection();
  const { isMobile, isTablet, deviceType, orientation, touchDevice } = deviceInfo;

  // Logging device information for debugging
  useEffect(() => {
    console.log("Device Info:", deviceInfo);
  }, [deviceInfo]);
  
  const handleGetStarted = () => {
    setLoading(true);
    try {
      setLocation("/auth");
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Something went wrong. Please try again."
      });
    } finally {
      setLoading(false);
    }
  };

  const scrollToSection = (sectionId: string) => {
    const section = document.getElementById(sectionId);
    section?.scrollIntoView({ behavior: 'smooth' });
    if (isMobile) {
      setShowMobileMenu(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-gray-50">
      {/* Enhanced Responsive Header */}
      <header className="fixed top-0 left-0 right-0 bg-gradient-to-r from-white/95 to-primary/5 backdrop-blur-md z-50 border-b shadow-sm transition-all duration-300">
        <div className="container mx-auto h-16 px-4 md:px-8 flex items-center justify-between">
          <div className="flex items-center gap-2 md:gap-8">
            {/* Logo with Animation */}
            <div 
              onClick={() => scrollToSection('home')}
              className="flex items-center gap-2 cursor-pointer group hover:scale-105 transform transition-all duration-300"
            >
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shadow-sm group-hover:shadow-md transition-all">
                <Briefcase className="h-5 w-5 text-primary group-hover:animate-bounce" />
              </div>
              <span className="font-bold text-xl text-gradient whitespace-nowrap">
                JobPulse
              </span>
            </div>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-2">
              <Button
                variant="ghost"
                onClick={() => scrollToSection('how-it-works')}
                className="active:animate-button-press whitespace-nowrap hover:bg-primary/10 transition-all duration-300"
              >
                <FileText className="h-4 w-4 mr-1" />
                How It Works
              </Button>
              <Button
                variant="ghost"
                onClick={() => scrollToSection('about-us')}
                className="active:animate-button-press whitespace-nowrap hover:bg-primary/10 transition-all duration-300"
              >
                <Info className="h-4 w-4 mr-1" />
                About Us
              </Button>
              <Button
                variant="ghost"
                onClick={() => scrollToSection('contact-us')}
                className="active:animate-button-press whitespace-nowrap hover:bg-primary/10 transition-all duration-300"
              >
                <Mail className="h-4 w-4 mr-1" />
                Contact Us
              </Button>
            </nav>
          </div>
          
          <div className="flex items-center gap-2">
            {/* User Authentication */}
            <div className="hidden md:block">
              <Button 
                variant="outline"
                size="sm"
                className="mr-2 hover:bg-primary/10 border-primary/20"
                onClick={() => setLocation('/auth')}
              >
                <LogIn className="h-4 w-4 mr-1" />
                Sign In
              </Button>
            </div>
            
            {/* Mobile Menu Button */}
            <Button 
              variant={showMobileMenu ? "default" : "ghost"}
              size="icon" 
              className="md:hidden rounded-full transition-colors duration-300"
              onClick={() => setShowMobileMenu(!showMobileMenu)}
            >
              {showMobileMenu ? (
                <X className="h-5 w-5 animate-fade-in" />
              ) : (
                <Menu className="h-5 w-5" />
              )}
            </Button>
          </div>
        </div>
        
        {/* Mobile Navigation Menu with Animation */}
        <div 
          className={`md:hidden fixed top-16 left-0 right-0 bg-white/95 backdrop-blur-sm border-t border-gray-100 px-4 py-2 overflow-hidden transition-all duration-300 ease-in-out shadow-lg ${
            showMobileMenu 
              ? 'max-h-[calc(100vh-4rem)] opacity-100 animate-slide-down' 
              : 'max-h-0 opacity-0 pointer-events-none'
          }`}
        >
          <nav className="flex flex-col space-y-2 py-2">
            <Button
              variant="ghost"
              onClick={() => scrollToSection('how-it-works')}
              className="justify-start px-2 active:animate-button-press hover:bg-primary/5"
            >
              <ArrowRight className="h-4 w-4 mr-2" />
              How It Works
            </Button>
            <Button
              variant="ghost"
              onClick={() => scrollToSection('about-us')}
              className="justify-start px-2 active:animate-button-press hover:bg-primary/5"
            >
              <ArrowRight className="h-4 w-4 mr-2" />
              About Us
            </Button>
            <Button
              variant="ghost"
              onClick={() => scrollToSection('contact-us')}
              className="justify-start px-2 active:animate-button-press hover:bg-primary/5"
            >
              <ArrowRight className="h-4 w-4 mr-2" />
              Contact Us
            </Button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="pt-24 pb-12 px-4">
        <div className="container mx-auto text-center max-w-4xl animate-fade-in">
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent mb-6 animate-slide-up">
            Welcome to JobPulse
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8 animate-slide-up">
            Experience the next generation of job search and career development tools.
          </p>
          <Button
            size="lg"
            onClick={handleGetStarted}
            disabled={loading}
            className="text-lg px-8 hover:scale-105 transition-transform active:animate-button-press"
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Loading...
              </>
            ) : (
              <>
                Get Started
                <ArrowRight className="ml-2 h-5 w-5" />
              </>
            )}
          </Button>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="container mx-auto px-4 py-12 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-8">Platform Statistics</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Stats cards */}
            <div className="text-center transform hover:scale-105 transition-transform">
              <h3 className="text-4xl font-bold text-primary mb-2">500K+</h3>
              <p className="text-muted-foreground">Active Users</p>
            </div>
            <div className="text-center transform hover:scale-105 transition-transform">
              <h3 className="text-4xl font-bold text-primary mb-2">1M+</h3>
              <p className="text-muted-foreground">Jobs Posted</p>
            </div>
            <div className="text-center transform hover:scale-105 transition-transform">
              <h3 className="text-4xl font-bold text-primary mb-2">90%</h3>
              <p className="text-muted-foreground">Success Rate</p>
            </div>
          </div>
          <div className="mt-8">
            <h3 className="text-2xl font-semibold mb-4">AI Provider Status</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* AI Provider - Gemini AI */}
              <div className="p-4 rounded-lg bg-gradient-to-br from-indigo-50 to-blue-100 border border-blue-200 shadow-sm hover:shadow-md transition-shadow duration-200 transform hover:scale-105">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-blue-600 animate-pulse" />
                    <span className="font-medium text-blue-900">Gemini AI</span>
                  </div>
                  <div className="flex flex-col items-end">
                    <span className="text-xs text-blue-600">Online</span>
                  </div>
                </div>
                <div className="mt-2 flex flex-col">
                  <div className="flex justify-between">
                    <span className="text-xs text-muted-foreground">Model:</span>
                    <span className="text-xs font-medium">Pro</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-xs text-muted-foreground">Status:</span>
                    <span className="text-xs font-medium text-green-600">Available</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-xs text-muted-foreground">Response time:</span>
                    <span className="text-xs font-medium">~1.2s</span>
                  </div>
                </div>
              </div>

              {/* AI Provider - DeepSeek */}
              <div className="p-4 rounded-lg bg-gradient-to-br from-purple-50 to-indigo-100 border border-purple-200 shadow-sm hover:shadow-md transition-shadow duration-200 transform hover:scale-105">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-purple-600 animate-pulse" />
                    <span className="font-medium text-purple-900">DeepSeek</span>
                  </div>
                  <div className="flex flex-col items-end">
                    <span className="text-xs text-purple-600">Online</span>
                  </div>
                </div>
                <div className="mt-2 flex flex-col">
                  <div className="flex justify-between">
                    <span className="text-xs text-muted-foreground">Model:</span>
                    <span className="text-xs font-medium">Chat</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-xs text-muted-foreground">Status:</span>
                    <span className="text-xs font-medium text-green-600">Available</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-xs text-muted-foreground">Response time:</span>
                    <span className="text-xs font-medium">~1.8s</span>
                  </div>
                </div>
              </div>

              {/* AI Provider - OpenAI */}
              <div className="p-4 rounded-lg bg-gradient-to-br from-emerald-50 to-teal-100 border border-emerald-200 shadow-sm hover:shadow-md transition-shadow duration-200 transform hover:scale-105">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
                    <span className="font-medium text-emerald-900">OpenAI</span>
                  </div>
                  <div className="flex flex-col items-end">
                    <span className="text-xs text-emerald-600">Online</span>
                  </div>
                </div>
                <div className="mt-2 flex flex-col">
                  <div className="flex justify-between">
                    <span className="text-xs text-muted-foreground">Model:</span>
                    <span className="text-xs font-medium">GPT-4</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-xs text-muted-foreground">Status:</span>
                    <span className="text-xs font-medium text-green-600">Available</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-xs text-muted-foreground">Response time:</span>
                    <span className="text-xs font-medium">~2.5s</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Us Section */}
      <section id="about-us" className="container mx-auto px-4 py-12 bg-white border-t border-b">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6 text-gradient">About Us</h2>
          <div className="prose prose-lg mx-auto">
            <p className="text-lg text-muted-foreground mb-6">
              We're your AI-powered career companion, combining cutting-edge artificial intelligence with
              human insight to revolutionize job searching. Our platform makes finding your dream job
              simpler and more effective than ever before.
            </p>
            <p className="text-lg text-muted-foreground">
              From resume crafting to interview preparation, we provide intelligent tools that adapt to
              your unique career journey, helping both fresh graduates and seasoned professionals advance
              their careers with confidence.
            </p>
          </div>
        </div>
      </section>

      {/* How It Works Section - Add id for scrolling */}
      <section id="how-it-works" className="container mx-auto px-4 py-8 bg-gray-50">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-8">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center transform hover:scale-105 transition-all duration-300 animate-fade-in">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4 animate-bounce">
                <FileText className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Upload Resume</h3>
              <p className="text-muted-foreground">
                Upload your resume and let our AI analyze your skills and experience
              </p>
            </div>
            <div className="flex flex-col items-center transform hover:scale-105 transition-all duration-300 animate-fade-in delay-150">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4 animate-bounce delay-150">
                <Search className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Match Jobs</h3>
              <p className="text-muted-foreground">
                Our AI matches you with the most relevant job opportunities
              </p>
            </div>
            <div className="flex flex-col items-center transform hover:scale-105 transition-all duration-300 animate-fade-in delay-300">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4 animate-bounce delay-300">
                <MousePointer className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Apply with Ease</h3>
              <p className="text-muted-foreground">
                Apply to multiple jobs with tailored applications in just one click
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="container mx-auto px-4 py-12 bg-white">
        <h2 className="text-3xl font-bold text-center mb-8">What Our Users Say</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          <Card className="transform hover:scale-105 transition-all duration-300">
            <CardContent className="pt-6">
              <p className="text-muted-foreground mb-4">"Found my dream job in just two weeks! The AI-powered matching system is incredible."</p>
              <div className="flex items-center gap-2">
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="font-semibold text-primary">JS</span>
                </div>
                <div>
                  <p className="font-semibold">John Smith</p>
                  <p className="text-sm text-muted-foreground">Software Engineer</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="transform hover:scale-105 transition-all duration-300">
            <CardContent className="pt-6">
              <p className="text-muted-foreground mb-4">"The resume analysis tool gave me insights I never would have thought of. Highly recommended!"</p>
              <div className="flex items-center gap-2">
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="font-semibold text-primary">AJ</span>
                </div>
                <div>
                  <p className="font-semibold">Alice Johnson</p>
                  <p className="text-sm text-muted-foreground">Marketing Manager</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="transform hover:scale-105 transition-all duration-300">
            <CardContent className="pt-6">
              <p className="text-muted-foreground mb-4">"The one-click apply feature saved me countless hours in my job search. Amazing platform!"</p>
              <div className="flex items-center gap-2">
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="font-semibold text-primary">RK</span>
                </div>
                <div>
                  <p className="font-semibold">Robert Kim</p>
                  <p className="text-sm text-muted-foreground">Data Scientist</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>


      {/* Contact Section Update */}
      <section id="contact-us" className="container mx-auto px-4 py-8 bg-white">
        <div className="max-w-2xl mx-auto text-center">
          <div className="flex items-center justify-center mb-2">
            <Mail className="h-8 w-8 text-primary mr-2" />
            <h2 className="text-3xl font-bold">Contact JobPulse</h2>
          </div>
          <p className="text-lg text-muted-foreground mb-6">
            Have questions? The JobPulse team is here to help you find the perfect job opportunity.
          </p>
          <Card className="p-6 transform transition-all duration-300 hover:shadow-lg">
            <CardContent>
              <p className="text-lg font-medium mb-4">Reach out to us at:</p>
              <p className="text-primary hover:text-primary/80 transition-colors mb-6">
                support@jobpulse.com
              </p>
              <div className="flex justify-center gap-4">
                <Button variant="ghost" size="icon" className="rounded-full hover:scale-110 transition-transform">
                  <Linkedin className="h-5 w-5" />
                </Button>
                <Button variant="ghost" size="icon" className="rounded-full hover:scale-110 transition-transform">
                  <Twitter className="h-5 w-5" />
                </Button>
                <Button variant="ghost" size="icon" className="rounded-full hover:scale-110 transition-transform">
                  <Github className="h-5 w-5" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
      {/* Copyright Footer */}
      <footer className="container mx-auto px-4 py-8 bg-white border-t">
        <div className="max-w-2xl mx-auto text-center">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} JobPulse. All rights reserved.
          </p>
          <p className="text-xs text-muted-foreground mt-2">
            This software is protected by copyright law. Unauthorized use, copying, or distribution is prohibited.
          </p>
        </div>
      </footer>
    </div>
  );
}