/**
 * JobPulse - Advanced Job Search Platform
 * Copyright (c) 2025 JobPulse. All rights reserved.
 * 
 * This source code is protected by copyright law.
 * Unauthorized copying or use is strictly prohibited.
 */

import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Shield, Lock, FileText } from "lucide-react";

export function TermsOfUse() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-2 mb-6">
          <Shield className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold">Terms of Use</h1>
        </div>
        
        <ScrollArea className="h-[60vh] rounded-md border p-6 bg-white">
          <div className="space-y-6">
            <section>
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <Lock className="h-5 w-5" />
                Intellectual Property Rights
              </h2>
              <p className="mt-2 text-muted-foreground">
                JobPulse and all its contents, features, and functionality (including but not limited to all information, software, text, displays, images, and the design and arrangement thereof), are owned by JobPulse, its licensors, or other providers of such material and are protected by international copyright, trademark, patent, trade secret, and other intellectual property or proprietary rights laws.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <FileText className="h-5 w-5" />
                License and Usage
              </h2>
              <p className="mt-2 text-muted-foreground">
                This software is licensed, not sold. JobPulse grants you a limited, non-exclusive, non-transferable license to use the application solely for your personal or internal business purposes in accordance with these terms.
              </p>
              <div className="mt-4 space-y-2">
                <h3 className="font-medium">Prohibited Actions:</h3>
                <ul className="list-disc list-inside text-muted-foreground">
                  <li>Copying, modifying, or distributing the software</li>
                  <li>Reverse engineering or attempting to extract the source code</li>
                  <li>Removing or altering any copyright notices</li>
                  <li>Using the software for any illegal purposes</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-xl font-semibold">Copyright Protection</h2>
              <p className="mt-2 text-muted-foreground">
                © {new Date().getFullYear()} JobPulse. All rights reserved. Any unauthorized use, reproduction, or distribution of this software or its content may result in severe civil and criminal penalties, and will be prosecuted to the maximum extent possible under law.
              </p>
            </section>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
