/**
 * JobPulse - Advanced Job Search Platform
 * Copyright (c) 2025 JobPulse. All rights reserved.
 * 
 * This source code is protected by copyright law.
 * Unauthorized copying or use is strictly prohibited.
 */

import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { MessageCircle, Send, X, Loader2, AlertCircle, Mic, Volume2, VolumeX, Bot, User } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type Message = {
  content: string;
  isUser: boolean;
  isError?: boolean;
  personality?: 'human' | 'robot';
};

export function ChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [currentPersonality, setCurrentPersonality] = useState<'human' | 'robot'>('human');
  const [messages, setMessages] = useState<Message[]>([
    { 
      content: "[HUMAN] Hi! I'm your AI assistant. I can switch between my human and robot sides to help you better. How can I help with your job search today?",
      isUser: false,
      personality: 'human'
    }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const { toast } = useToast();
  const speechRecognition = useRef<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Initialize speech recognition
  const initSpeechRecognition = () => {
    if ('webkitSpeechRecognition' in window) {
      speechRecognition.current = new (window as any).webkitSpeechRecognition();
      speechRecognition.current.continuous = false;
      speechRecognition.current.interimResults = false;

      speechRecognition.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInput(transcript);
        setIsListening(false);
        handleSend(transcript);
      };

      speechRecognition.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        toast({
          variant: "destructive",
          title: "Voice Input Error",
          description: "Failed to recognize speech. Please try again or type your message.",
        });
      };
    }
  };

  // Text to speech with personality-based settings
  const speak = (text: string, personality: 'human' | 'robot' = 'human') => {
    if ('speechSynthesis' in window) {
      setIsSpeaking(true);
      const utterance = new SpeechSynthesisUtterance(text.replace(/\[HUMAN\]|\[ROBOT\]/g, ''));

      // Adjust voice settings based on personality
      const voiceSettings = personality === 'robot' 
        ? { pitch: 0.8, rate: 1.1, voiceGender: 'Male' }
        : { pitch: 1.2, rate: 1.0, voiceGender: 'Female' };
      
      utterance.pitch = voiceSettings.pitch;
      utterance.rate = voiceSettings.rate;
      utterance.voice = speechSynthesis.getVoices().find(voice => 
        voice.name.includes(voiceSettings.voiceGender)
      ) || null;

      utterance.onend = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    }
  };

  const togglePersonality = () => {
    setCurrentPersonality(prev => prev === 'human' ? 'robot' : 'human');
    const newPersonality = currentPersonality === 'human' ? 'robot' : 'human';
    const message = newPersonality === 'human' 
      ? "[HUMAN] Switching to human mode. I'll be more empathetic and casual in my responses."
      : "[ROBOT] Initiating robot mode. Engaging precise and technical communication protocols.";

    setMessages(prev => [...prev, { 
      content: message,
      isUser: false,
      personality: newPersonality
    }]);
  };

  // Other voice-related functions remain the same
  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  const startVoiceInput = () => {
    if (!speechRecognition.current) {
      initSpeechRecognition();
    }

    if (speechRecognition.current) {
      setIsListening(true);
      speechRecognition.current.start();
    } else {
      toast({
        variant: "destructive",
        title: "Not Supported",
        description: "Speech recognition is not supported in your browser.",
      });
    }
  };

  const stopVoiceInput = () => {
    if (speechRecognition.current) {
      speechRecognition.current.stop();
      setIsListening(false);
    }
  };

  const handleSend = async (voiceInput?: string) => {
    const messageToSend = voiceInput || input;
    if (!messageToSend.trim()) return;

    try {
      setIsLoading(true);
      const userMessage = messageToSend.trim();
      setMessages(prev => [...prev, { content: userMessage, isUser: true }]);
      setInput("");

      const response = await fetch('/api/chat', {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Accept": "application/json",
          // Add copyright protection header
          "X-JobPulse-Protected": "true"
        },
        body: JSON.stringify({ 
          message: userMessage,
          personality: currentPersonality
        })
      });

      const data = await response.json();

      if (!response.ok || data.error) {
        const errorMessage = data.message || 'Failed to get AI response. Please try again.';
        throw new Error(errorMessage);
      }

      // Add watermark to AI responses
      const aiResponse = data.response;
      const watermarkedResponse = `${aiResponse}\n\n© ${new Date().getFullYear()} JobPulse AI`;

      setMessages(prev => [...prev, { 
        content: watermarkedResponse,
        isUser: false,
        personality: data.personality || (aiResponse.includes('[HUMAN]') ? 'human' : 'robot')
      }]);

      if (voiceInput && !isSpeaking) {
        speak(watermarkedResponse, data.personality);
      }

    } catch (error: any) {
      console.error('Chat error:', error.message);
      setMessages(prev => [...prev, { 
        content: error.message || "The AI assistant is temporarily unavailable. Please try again in a few minutes.", 
        isUser: false,
        isError: true
      }]);

      toast({
        variant: "destructive",
        title: "AI Assistant Error",
        description: error.message || "The AI assistant is temporarily unavailable. Please try again in a few minutes.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {isOpen ? (
        <Card className="w-[350px] h-[500px] flex flex-col shadow-xl">
          <div className="flex items-center justify-between p-4 border-b">
            <div className="flex items-center gap-2">
              <h3 className="font-semibold">AI Assistant</h3>
              <div 
                className={cn(
                  "relative w-12 h-6 rounded-full transition-colors duration-300 cursor-pointer",
                  currentPersonality === 'human' ? "bg-blue-100" : "bg-slate-800"
                )}
                onClick={togglePersonality}
              >
                <div
                  className={cn(
                    "absolute top-1 w-4 h-4 rounded-full transition-all duration-300 transform",
                    currentPersonality === 'human'
                      ? "left-1 bg-blue-500"
                      : "left-7 bg-slate-200"
                  )}
                >
                  {currentPersonality === 'human' ? (
                    <User className="w-4 h-4 text-white p-0.5" />
                  ) : (
                    <Bot className="w-4 h-4 text-slate-800 p-0.5" />
                  )}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => {
                  setMessages([{ 
                    content: "[HUMAN] Hi! I'm your AI assistant. I can switch between my human and robot sides to help you better. How can I help with your job search today?",
                    isUser: false,
                    personality: 'human'
                  }]);
                }}
                className="text-xs"
              >
                Clear Chat
              </Button>
              <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex ${message.isUser ? "justify-end" : "justify-start"} animate-slide-up`}
              >
                <div
                  className={cn(
                    "max-w-[80%] p-3 rounded-lg",
                    message.isUser
                      ? "bg-primary text-primary-foreground"
                      : message.isError
                      ? "bg-destructive/10 text-destructive flex items-center gap-2"
                      : message.personality === 'robot'
                      ? "bg-slate-800 text-slate-100"
                      : "bg-blue-100 text-blue-900",
                    "transform transition-all duration-300 hover:scale-[1.02]"
                  )}
                >
                  {message.isError && <AlertCircle className="h-4 w-4" />}
                  {message.content.replace(/\[(HUMAN|ROBOT)\]/g, '')}
                  {!message.isUser && !message.isError && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="ml-2 h-6 w-6"
                      onClick={() => isSpeaking ? stopSpeaking() : speak(message.content, message.personality)}
                    >
                      {isSpeaking ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                    </Button>
                  )}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </CardContent>
          <div className="p-4 border-t">
            <div className="flex gap-2">
              <Input
                placeholder="Type your message..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && !isLoading && handleSend()}
                disabled={isLoading || isListening}
              />
              <Button
                variant="ghost"
                size="icon"
                onClick={() => isListening ? stopVoiceInput() : startVoiceInput()}
                className={`${isListening ? 'text-red-500' : ''}`}
                disabled={isLoading}
              >
                <Mic className="h-4 w-4" />
              </Button>
              <Button 
                onClick={() => handleSend()} 
                disabled={isLoading || isListening}
                className="active:animate-button-press"
              >
                {isLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>
        </Card>
      ) : (
        <Button
          onClick={() => setIsOpen(true)}
          size="lg"
          className="rounded-full w-12 h-12 shadow-lg active:animate-button-press"
        >
          <MessageCircle className="h-6 w-6" />
        </Button>
      )}
    </div>
  );
}